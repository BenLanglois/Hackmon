#ifndef ACTIONINFO_H
#define ACTIONINFO_H

enum Scope {
  SINGLE,
  ALL
};

#endif
