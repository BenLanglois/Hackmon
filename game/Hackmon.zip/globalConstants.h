#ifndef GLOBAL_CONSTANTS_H_
#define GLOBAL_CONSTANTS_H_

extern unsigned numberBattling;
extern int numberParty;
extern int numberOfItems;

#endif
