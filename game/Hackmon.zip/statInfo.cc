#include "statInfo.h"

#include <map>
#include <string>

using namespace std;
map<StatName, string> statString = {
  {HP, "Hp"},
  {ATTACK, "Attack"},
  {DEFENSE, "Defense"},
  {SPEED, "Speed"}
};