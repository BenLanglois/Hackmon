#include "globalConstants.h"

unsigned numberBattling;
int numberParty = 3;
int numberOfItems = 3;
